# Mahzarb Studio Website

Static website built for GitHub Pages.

## Before publishing
Open `script.js` and replace:
`923000000000`
with the Mahzarb Studio WhatsApp number in international format, without `+`.

Example:
`923001234567`

## Publish
1. Create a GitHub repository.
2. Upload `index.html`, `style.css`, and `script.js`.
3. In GitHub: Settings → Pages.
4. Select Deploy from branch → main → / (root).
5. Save and wait for the live URL.

Tagline: Mahzarb Studio — Customize Your Feelings.
